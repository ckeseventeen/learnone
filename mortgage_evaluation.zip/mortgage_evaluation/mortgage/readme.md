THIS IS THE README FOR MORTGAGE.PY

RUN obj.get_weight() IN MAIN.PY FIRST AND NEVER RUN IT AGAIN
THEN RUN obj.data_hive_test() 
FINALLY obj.mort_analysis()